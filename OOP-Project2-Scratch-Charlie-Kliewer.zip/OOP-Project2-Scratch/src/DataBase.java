import java.util.*;
public class DataBase implements Server {

    ArrayList<Client> ClientList;

    DataBase(){
        ClientList = new ArrayList<Client>();
    }

    @Override
    public void attach(Client c) {
        ClientList.add(c);
    }

    @Override
    public Client detach(Client c) {
        return null;
    }

    @Override
    public void NotifyClient(Message m) {
        for(Client e : ClientList) {
            e.update(m);
            System.out.println("Running update for user: " + Integer.toString(e.getNum()));
        }
    }

    public int getLength(){
        return ClientList.size();
    }
}
