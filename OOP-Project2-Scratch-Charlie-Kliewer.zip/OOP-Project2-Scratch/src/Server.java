public interface Server {
    void attach(Client c);
    Client detach(Client c);
    void NotifyClient(Message m);
}
