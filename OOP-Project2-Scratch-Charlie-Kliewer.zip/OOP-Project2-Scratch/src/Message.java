public class Message {
    String text;
    String sender;
    Message(String s, String se){
        text = s;
        sender = se;
    }
    public String getText(){
        return text;
    }
    public void setText(String s){
        text = s;
    }
    public void setSender(String s){
        sender = s;
    }
}
