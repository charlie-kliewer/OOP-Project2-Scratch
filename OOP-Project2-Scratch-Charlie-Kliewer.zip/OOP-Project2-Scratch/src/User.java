public class User implements Client {

    DataBase dataBase;
    UI ui;
    public int num;

    User(DataBase d){
        dataBase = d;
        dataBase.attach(this);
        ui = new UI(dataBase.getLength(), this);
        num = dataBase.getLength();
        System.out.println(dataBase.ClientList);
    }

    @Override
    public void notify(Message m) {
        dataBase.NotifyClient(m);
    }

    @Override
    public void update(Message m) {
        ui.addMessageToLog(m);
        System.out.println("addMessageToLog running for Sender #" + Integer.toString(num));
    }

    public int getNum(){
        return num;
    }

}
