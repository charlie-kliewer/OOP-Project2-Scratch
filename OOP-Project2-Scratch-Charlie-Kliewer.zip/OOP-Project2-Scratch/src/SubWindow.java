import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import javax.swing.*;

public class SubWindow {
    DataBase db;

    SubWindow(DataBase d){
        db = d;
        JFrame window = new JFrame();
        window.setSize(300,300);
        window.setLocation(100,100);
        window.setTitle("Add new chatter?");
        JButton jb = new JButton("Click here!");
        window.add(jb);
        jb.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                new User(d);
            }
        });
        window.setVisible(true);
    }

    public DataBase getDB(){
        return db;
    }
}
