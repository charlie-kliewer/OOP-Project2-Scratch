import java.awt.*;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

public class UI extends JFrame {

    Client c;

    ActionListener s = new ActionListener() {
        public void actionPerformed(ActionEvent e) {
            currentMessage.text = messages.getText();
            c.notify(currentMessage);
            messages.setText("");

        }
    };

    JFrame frame;
    JButton send;
    JLabel x;
    JTextArea messages;
    private String text;
    public Message currentMessage;

    private Font f = new Font("Sans Serif", Font.BOLD, 13);
    public String name;

    UI(int i, Client ce) {
        super("Chatter" + Integer.toString(i));
        currentMessage = new Message("", "Sender #"+Integer.toString(i));
        text = "";
        c = ce;
        x = new JLabel();
        frame = new JFrame("Chatter #" + Integer.toString(i));
        send = new JButton("Send");
        send.addActionListener(s);
        messages = new JTextArea();
        JPanel p = new JPanel();
        p.setLayout(new GridLayout(3,1));
        p.add(x);
        p.add(send);
        p.add(messages);
        frame.add(p);
        frame.setSize(300,600);
        frame.setVisible(true);

    }

    void addMessageToLog(Message m){
        text = text + "<br>" + m.sender + ": " + m.text;
        x.setText("<html>" + text + "</html>");
    }
}


