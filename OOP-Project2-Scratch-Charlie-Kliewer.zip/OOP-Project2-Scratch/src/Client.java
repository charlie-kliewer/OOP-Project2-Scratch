public interface Client {
    int getNum();
    void notify(Message m);
    void update(Message m);
}
