public class Main {
    public static void main(String[] args){
        DataBase db = new DataBase();
        SubWindow sub = new SubWindow(db);
    }
}
